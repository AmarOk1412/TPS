/** \brief Ce fichier doit contenir la déclaration de la classe vecteur
    Attention, elle ne doit contenir aucune implémentation de méthode / fonction
*/

#ifndef _VECTEUR_H
#define _VECTEUR_H

// Déclaration de la classe vecteur
class Vecteur {
private :
  // attributs

public :
  // prototypes des constructeurs et autres méthodes publiques

private :
  // méthodes privées d'implémentation (si besoin)
};

// Prototypes des fonctions

#endif
