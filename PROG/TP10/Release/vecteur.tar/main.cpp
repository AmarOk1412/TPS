#include "vecteur.h"

/** \brief Programme principal */
int main()
{
  /** Insérez votre code ici... */

  return 0 ;
}
